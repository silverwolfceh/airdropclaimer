function getAuthHeaders() {
	toplevel = document.getElementById("toplevel").value;
	chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
		chrome.runtime.sendMessage({ action: "getRecordedRequests", "page" :  toplevel}, (response) => {
			const requestList = document.getElementById("requestList");
			if (response && response.length) {
				logdata = "";
				response.forEach((request) => {
					if (request.topLevelUrl.indexOf(toplevel) != -1) {
						logdata += `URL: ${request.topLevelUrl} - ` + `Type: ${request.type} - ` + `Auth: ${request.authorization}` + "\n";
						authdata = `${request.authorization}`;
					}
				});
				requestList.innerHTML = logdata;
			} else {
				requestList.innerHTML = "No authorization / token headers recorded.";
			}
		});
	});
}

function getTelegramInitData() {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (chrome.runtime.lastError) {
            console.error('Error querying tabs:', chrome.runtime.lastError.message);
            return;
        }

        if (tabs && tabs.length > 0) {
            chrome.tabs.sendMessage(tabs[0].id, { action: "getSessionStorage" }, function(response) {
                if (chrome.runtime.lastError) {
                    console.error('Error sending message:', chrome.runtime.lastError.message);
                    return;
                }

                try {
					if(response == undefined || !("data" in response)) {
						return;
					}
                    const jsondata = JSON.parse(response.data);
                    console.log('Parsed JSON data:', jsondata);

                    if ("__telegram__initParams" in jsondata && "tgWebAppData" in JSON.parse(jsondata["__telegram__initParams"])) {
                        // Handle initialization parameters
                        console.log('Telegram Init Params:', jsondata["__telegram__initParams"]);
						document.getElementById("requestList").value = JSON.parse(jsondata["__telegram__initParams"])["tgWebAppData"];
                        // Optionally update UI or perform further actions
                    } else {
                        document.getElementById("requestList").value = 'No __telegram__initParams found in session storage. Try again';
                    }
                } catch (err) {
					document.getElementById("requestList").value = 'Error parsing JSON';
                    console.error('Error parsing JSON:', err);
                }
            });
        } else {
            console.error('No active tabs found.');
        }
    });
}


function getTelegramInitData1() {
	chrome.runtime.sendMessage({ action: "getTelegramData", "page" :  toplevel}, (response) => {
		if(response == undefined)
			return;
		try {
			jsondata = JSON.parse(response.data);
			console.log(jsondata);
			if("__telegram__initParams" in jsondata) {
				jsondata1 = JSON.parse(jsondata["__telegram__initParams"]);
				const requestList = document.getElementById("requestList");
				const dt = {
					'url' : decodeURIComponent(response.url.split("#")[0]),
					'initparams' : decodeURIComponent(jsondata1["tgWebAppData"])
				}
				requestList.innerHTML = JSON.stringify(dt);
			}
		} catch (err) {
			console.log(err);
		}
	});
}

function convertInitData() {

}

// function getTelegramWebData() {
// 	chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
// 		var currentPageUrl = tabs[0].url;
// 		chrome.runtime.sendMessage({ action: "getTelegramData", "page" :  currentPageUrl}, (response) => {
// 			const requestList = document.getElementById("requestList");
// 			if (response && response.length) {
// 				console.log(response);
// 				logdata = response;
// 				// response.forEach((request) => {
// 				// 	logdata = request;
// 				// 	// logdata += `URL: ${request.url} - ` + `Type: ${request.type} - ` + `Auth: ${request.authorization}` + "\n";
// 				// 	// authdata = `${request.authorization}`;
					
// 				// });
// 				requestList.innerHTML = logdata;
// 			} else {
// 				requestList.innerHTML = "No storage data";
// 			}
// 		});
// 	});
// }

document.addEventListener('DOMContentLoaded', function () {
	var getAuthBtn = document.getElementById('getAuth');
	getAuthBtn.addEventListener('click', getAuthHeaders);
	var getTelegramBtn = document.getElementById('getTeleData');
	getTelegramBtn.addEventListener('click', getTelegramInitData);
});

window.addEventListener('blur', () => {
	window.focus();
  });