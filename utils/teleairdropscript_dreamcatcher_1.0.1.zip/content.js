console.log('Content script loaded');

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    console.log('Message received in content script:', message);
    if (message.action === "getSessionStorage") {
      const sessionStorageData = JSON.stringify(sessionStorage);
      sendResponse({ data: sessionStorageData });
    }
  });
  