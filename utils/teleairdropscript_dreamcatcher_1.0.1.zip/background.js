const recordedRequests = [];

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    // Check if the request is coming from an iframe
    if (true) {
      // Get the URL of the top-level frame (parent frame)
      const topLevelUrl = new URL(details.initiator).origin;
      
      // Extract authorization header if present
      const authorizationHeader = details.requestHeaders.find(header => header.name.toLowerCase() === 'authorization');
      const tokenHeader = details.requestHeaders.find(header => header.name.toLowerCase() === 'token');
      
      if (authorizationHeader || tokenHeader) {
        const data = {
          topLevelUrl: topLevelUrl,
          iframeUrl: details.url,
          method: details.method,
          authorization: authorizationHeader ? authorizationHeader.value : tokenHeader.value,
          type: authorizationHeader ? "authorization" : "token"
        };
        
        recordedRequests.push(data);
        chrome.storage.local.set({ recordedRequests });
        console.log("Recorded Authorization Header for iframe: ", data);
      }
    }
  },
  { urls: ["<all_urls>"] },
  ["requestHeaders"]
);

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Received message:', request, sender);
  if (request.action === "getRecordedRequests") {
    chrome.storage.local.get("recordedRequests", (data) => {
      sendResponse(data.recordedRequests);
    });
    return true; // Indicate that the response will be sent asynchronously
  }
  if (request.action === "getTelegramData") {
    chrome.tabs.query({ active: false, currentWindow: true }, function(tabs) {
      console.log('Tabs queried:', tabs);
      if (tabs && tabs.length > 0) {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, { action: "getSessionStorage" }, function(response) {
            try {
              const jsondata = JSON.parse(response);
              console.log('Parsed JSON data:', jsondata);
              if ("__telegram__initParams" in jsondata) {
                sendResponse(jsondata["__telegram__initParams"]);
                return; // Exit function after sending response
              }
            } catch (err) {
              console.error('Error parsing JSON:', err);
            }
          });
        });
      } else {
        console.error('No active tabs found.');
        // Optionally handle case when no active tabs are found
        // sendResponse(null);
      }
    });
    return true; // Return true to indicate asynchronous response
  }
});
